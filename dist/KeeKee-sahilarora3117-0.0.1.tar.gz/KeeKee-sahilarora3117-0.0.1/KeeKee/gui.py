import gi
gi.require_version('Gtk', '3.0')
from gi.repository import GLib, Gtk, GObject, Gdk

class selectorWindow (Gtk.Window):
	def __init__(self):
		Gtk.Window.__init__(self, title="Select or Create a KBDX file")
		self.set_border_width(10)
		self.set_default_size(700, 400)
		grid = Gtk.Grid ()
		grid.orientation = Gtk.Orientation.VERTICAL
		grid.row_spacing = 6
		grid.column_spacing = 6
		openButton = Gtk.Button(label = "Open an existing KBDX file")
		openButton.connect ("clicked", self.onOpenBtnClick)
		newButton = Gtk.Button(label= "Create a new KBDX file")
		newButton.connect ("clicked", self.onNewBtnClick)
		grid.attach(openButton,1,0,1,1)
		grid.attach(newButton,1,1,1,1)
		self.add(grid)
	def onOpenBtnClick(self, widget):
		dialog = Gtk.FileChooserDialog("Select a KBDX File", self, Gtk.FileChooserAction.OPEN,("Cancel", Gtk.ResponseType.CANCEL, "Open", Gtk.ResponseType.OK))
		response = dialog.run()
		if response == Gtk.ResponseType.OK:
			global file_path
			file_path = dialog.get_filename()
			# winnew = passEntry()
			# winnew.connect("destroy", Gtk.main_quit)
			# winnew.show_all()
		elif response == Gtk.ResponseType.CANCEL:
			print("No file Choosen")
		dialog.destroy()
	def onNewBtnClick(self, widget):
		print("Add new, Will work on this later")
def initialize_gui():
    win = selectorWindow()
	win.connect("destroy", Gtk.main_quit)
	win.show_all()

